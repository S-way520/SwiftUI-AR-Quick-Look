import SwiftUI
struct ContentView: View {
    @State var ARshow = false
    var body: some View {
        ARShow(ARImage: "tutorial", ARText1: "1.1", ARText2: "tutorial", ARName: "tutorial", ARshow: ARshow)
        //你只需要一行代码即可打开AR模型
        //You only need one line of code to open the AR model
        //ARShow(
    }
}
 
