import SwiftUI
import QuickLook
import ARKit
struct QLModel: UIViewControllerRepresentable {
    var name: String
    var allowScaling: Bool = true
    func makeCoordinator() -> QLModel.Coordinator {
        Coordinator(self)
    }
    func makeUIViewController(context: Context) -> QLPreviewController {
        let controller = QLPreviewController()
        controller.dataSource = context.coordinator
        return controller
    }
    func updateUIViewController(_ controller: QLPreviewController, context: Context) { }
    class Coordinator: NSObject, QLPreviewControllerDataSource {
        let parent: QLModel
        private lazy var fileURL: URL = Bundle.main.url(forResource: parent.name, withExtension: "reality")!//usdz
        init(_ parent: QLModel) {
            self.parent = parent
            super.init()
        }
        func numberOfPreviewItems(in controller: QLPreviewController) -> Int { return 1 }
        func previewController(_ controller: QLPreviewController, previewItemAt index: Int) -> QLPreviewItem {
            guard let fileURL = Bundle.main.url(forResource: parent.name, withExtension: "reality") else {
                fatalError("Unable to load \(parent.name).reality from main bundle")}//usdz
            let item = ARQuickLookPreviewItem(fileAt: fileURL)
            item.allowsContentScaling = parent.allowScaling
            return item
        }
    }
}
struct ARShow: View {
    @Environment(\.colorScheme) var colorScheme//暗黑模式
    var ARImage: String
    var ARText1: String
    var ARText2: String
    var ARName: String
    @State var ARshow = false
    func simpleSuccess() {UINotificationFeedbackGenerator().notificationOccurred(.success)}
    var body: some View {
        HStack{
            Button(action: {self.ARshow.toggle()}){
                Image(ARImage)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 80, height: 80)
                    .background(Color.gray.opacity(0.1))
                    .cornerRadius(10, antialiased: true)
                Text(ARText1)
                    .foregroundColor(.orange)
                Text(ARText2)
                    .multilineTextAlignment(.leading)
                    .foregroundColor(colorScheme == .light ? .black : .white)
            }
            .fullScreenCover(isPresented: $ARshow){
                ZStack{
                    QLModel(name: ARName).edgesIgnoringSafeArea(.all)
                    VStack{
                        Button(action: {self.ARshow.toggle(); simpleSuccess()}, label: {
                            HStack{
                                Image(systemName: "chevron.backward.circle")
                                    .font(.title3)
                                Spacer()
                                
                            }
                        })
                        .padding()
                        Spacer()
                    }
                }
            }
            Spacer()
        }
    }
}
